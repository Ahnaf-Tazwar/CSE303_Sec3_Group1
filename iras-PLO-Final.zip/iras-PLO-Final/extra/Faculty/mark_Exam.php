<?php
session_start();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Exam</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="facultyStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
   


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>


</head>


<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Exams</a>

        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="data">

                <a href="dashboard_Faculty.php"><button type="button" class="btn btn-success">Main Page</button></a>
                <a href="makeQuestions.php"><button type="button" class="btn btn-success">Make questions</button></a>
                <a href="../index.php"><button type="button" class="btn btn-success">CQI Reports</button></a>

            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <h1>Upcoming Exams:</h1>

    <form action="mark_Exam2.php" id="contentLoader1div" class="content1" method="POST" style="display: block;">
        <h5 style="text-align: center;">Load and mark Exam</h5>
        <h5 style="text-align: center; color: blue;">Summer 2021</h5>
        <p></p>
        <div class="dropDownWrapper" align="center">
            <select name="loadExam" class="form-select">
                <option selected disabled> <i>Course List </i></option>
                <option value="CSC101_1_quiz_1"> CSC101 - Section: 1 | Quiz 1</option>
                <option value="CSC203_4_quiz_2"> CSC203 - Section: 4 | Quiz 2</option>
                <option value="CSC203L_4_mid"> CSC203L - Section: 4 | Mid Term</option>
                <option value="CSC101L_1_final"> CSC101L - Section: 1 | Final Term</option>
            </select>
        </div>
        <br>
        <div align="center">
            <input type="submit" class="btn btn-primary text-white shadow" value="Load Exam">
        </div>
    </form>




    <script>
        function startResigtration() {
            document.getElementById("statusID").value = "true";
        }


    </script>
</body>

</html>
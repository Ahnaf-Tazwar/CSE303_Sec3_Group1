<?php
session_start();


//$isExam = false;
$isExam = true;
$quesID = isset($_POST['quesID']) ? $_POST['quesID'] : null;


date_default_timezone_set("Indian/Chagos");

$asd = date('d M Y');


echo '<br>'.date('D M d Y H:i:s:O');

// Prints something like: Monday
//echo date("l");

// Prints something like: Monday 8th of August 2005 03:12:46 PM
//echo "<br>".date('l jS \ F Y h:i:s A');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <!-- <script src="../../scripts/repeater.js"></script> -->
    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>


</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Up-Coming Exams</a>



        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="datas">

                <a href="dashboard_Student.php"><button type="button" class="btn btn-success but" id="contentLoader">Main Page</button></a>
                <a href="loadPastExams.php"><button type="button" class="btn btn-success">Load Past Exams</button></a>


            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <br>
    <h1>Exam type and other necessary information will be displayed here!</h1>

    <p id="demo" style="text-align: center; font-size: 60px; margin-top: 3vh;"><strong></strong></p>

    <form action="submitAnswer.php" id="contentLoader1div" class="questionForm" method="POST" enctype="multipart/form-data">
        <!--<label style="align-items: center;">Available PLOs for the course: </label>-->
        <h5 style="text-align: center;">This is for Exam: <?php echo $quesID; ?></h5>
        <p>Necessary information/ rules for the exam</p>

        <div class="input_fields_wrap">
            <div class="row ansSection">
                <div class="col-md-11">

                    <?php
                    for ($x = 1; $x <= 2; $x++) {
                        echo '&nbsp&nbsp&nbsp<h4 style = "color: skyblue;" align = "center" name="myAnswers[]" id="course_description" required>
                        <strong>This is Question No. ' . $x . '</strong></h4>
                        <p>What do you mean by Data Base?</p>
                        <input type="file" name="myfile[]" required > <br><br>';
                    }
                    ?>
                </div>
            </div>
        </div>

        <div align="center">
            <input type="submit" id="lockSubmit" style="width: 100%; height: 5vh;" class="btn btn-primary text-white shadow" value="Submit" />
        </div>
    </form>


    <script src="../../scripts/jquery.min.js"></script>




    <script>
        // Set the date we're counting down to
        //var countDownDate = new Date();
        var countDownDate = new Date(Date.parse('<?php echo $asd; ?>'));
        //var countDownDate = new Date(Date.parse("18 May 2021"));
        console.log(countDownDate);
        countDownDate = new Date();
        //var countDownDate = new Date();
        //countDownDate.setMinutes(countDownDate.getMinutes() + 2);
        countDownDate.setSeconds(countDownDate.getSeconds() + 30);

        // Update the count down every 1 second
        var x = setInterval(function() {

            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds

            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = hours + "h " + minutes + "m " + seconds + "s ";

            if (hours == 0) {
                if (minutes == 0) {
                    document.getElementById("demo").innerHTML = seconds + "s ";
                } else {
                    document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
                }
            }


            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "Exam Time Is Over!";
                document.getElementById("demo").style.color = "red";
                document.getElementById("lockSubmit").disabled = true;
                document.getElementById("lockSubmit").value = "Submission Time is Over!";
                document.getElementById("lockSubmit").style.backgroundColor = "red";
            }
        }, 1000);
    </script>

    <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>
<?php
session_start();


$One = "One";
$Two = "Two";
$Three = "Three";
$Four = "Four";
$Five = "Five";

//$isExam = false;
$isExam = true;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <!-- <script src="../../scripts/repeater.js"></script> -->
    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>


</head>
<style>
    
</style>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Past Exams</a>



        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="datas">

                <a href="dashboard_Student.php"><button type="button" class="btn btn-success but" id="contentLoader">Main Page</button></a>
                <!-- <a href="upComingExams.php"><button type="button" class="btn btn-success">Up-coming Exams</button></a> -->
                

            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <br>
    <h1 align = "center">Exams that are taken in Autumn 2021</h1>
    <br>


    <div class="wrapper">
    
    <?php
    
    for ($i = 0; $i < 10; $i++) {
        echo "<div class = \"loadExam\">

        <p>Upcoming Exams: ".($i + 1)."</p>
        <p>Exam type: Mid Term</p>
        <p>Course ID: CSC101</p>
        <p>Section: 1</p>
        <p>Syllabus: Varialbes, Loops and Functions</p>
        <p>Exam Time: 11.00 am | 25-April-2123123021</p>

    </div>";
    }

    ?>
</div>

    <!-- <script src="../../scripts/jquery.min.js"></script> -->




    <script>

        /*
        var asd = "<?php echo $isExam; ?>";

        if (asd) {
            $(".upcomingExamDiv").hide();
            var id = document.getElementById("myChart");
            id.style.margin = "auto";
        }*/


        /*var flag = true;

        $(function() {
            $(".but").on("click", function(e) {
                e.preventDefault();
                if (flag) {
                    trigger("myChart");
                    $("#" + this.id + "div").fadeIn(700);
                    flag = false;
                } else {
                    flag = true;
                    trigger("contentLoaderdiv");
                    trigger("myChart");
                    $("myChart").fadeIn(700);
                }
            });
        });*/


        function trigger(val) {
            var id = document.getElementById(val);
            if (id.style.display === "none") {
                id.style.display = "block";
            } else {
                id.style.display = "none";
            }
        }
    </script>

    <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>
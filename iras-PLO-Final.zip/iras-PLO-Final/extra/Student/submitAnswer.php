<?php
session_start();

//$file = $_FILES['myfile'];
$file = isset($_FILES['myfile']) ? $_FILES['myfile'] : null;
//echo "File Name<b>::</b> " . $file['name'][0];

for ($i = 0; $i < count($file['name']); $i++){
    echo "File Name<b>::</b> " . $file['name'][$i];
    move_uploaded_file($file['tmp_name'][$i],"answers/".$file['name'][$i]);  
}

/*move_uploaded_file($file['tmp_name'][0],"answers/".$file['name'][0]);
move_uploaded_file($file['tmp_name'][1],"answers/".$file['name'][1]);*/


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="studentStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>



    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/jquery.min.js"></script>
    <script src="../../scripts/Chart.js"></script>


</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Up-Coming Exams</a>



        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="datas">

                <a href="dashboard_Student.php"><button type="button" class="btn btn-success but" id="contentLoader">Main Page</button></a>
                <a href="loadPastExams.php"><button type="button" class="btn btn-success">Load Past Exams</button></a>
                

            </div>

            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <h1>Submission Confirmation</h1>









</body>

</html>
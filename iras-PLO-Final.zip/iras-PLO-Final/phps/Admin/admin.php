<?php
    include '../../connection.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/logo1.png">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="adminStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>
    <script>
        $(document).ready(function(){
            $("#course_dropDown").change(function(){
                $(this).find("option:selected").each(function(){
                    var optionValue = $(this).attr("value");
                    if(optionValue){
                        $(".box").not("." + optionValue).hide();
                        $("." + optionValue).show();
                    } else{
                        $(".box").hide();
                    }
                });
            }).change();
        });
        // $(document).ready(function(){
        //     $("#univerist").change(function(){
        //         $(this).find("option:selected").each(function(){
        //             var optionValue = $(this).attr("value");
        //             if(optionValue){
        //                 $(".box").not("." + optionValue).hide();
        //                 $("." + optionValue).show();
        //             } else{
        //                 $(".box").hide();
        //             }
        //         });
        //     }).change();
        // });
        var p = "Independent University, Bangladesh";
        function setValue(){
            a = document.getElementById("university").selectedIndex;
            x = document.getElementById("university").options[a].text;
            //alert(x);

        }

    // load edit
    $(function() {
        $(".but1").on("click", function(e) {
            e.preventDefault();
            $("#" + this.id + "div").fadeIn(700);
            trigger("form1");
        });
    });

    function trigger(val) {
        var id = document.getElementById(val);
        if (id.style.display === "none") {
            id.style.display = "block";
        } else {
            id.style.display = "none";
        }
    }
    </script>
    <style>
        
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Home</a>


        <div class="dropDownWrapper">
            <select id="course_dropDown" class="form-select">
                <option selected disabled> <i>Create Account </i></option>
                <option value="university"> University Account</option>
                <option value="school"> School Account</option>
                <option value="department"> Department Account</option>
            
            </select>
        </div>
        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

            <ul class="navbar-nav ml-auto">
            <div class="navbar-text ml-lg-3">
                    Admin Panel
                </div>
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    


    <div class="university box">
        <form action="university.php" id="form"method="POST" align="center">
        <br> <br>
            <h5 style="text-align: center;">Please Fill Up form to create University Account</h5>

            <input type="text" id="uniName" name="uniName" style="width:35%;padding: 5px;" require placeholder="University Name "> <br> <br>
            <input type="text" id="location"name="location" style="width:35%;padding: 5px;" require placeholder="University location "> <br> <br>


            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>

    </div>
    <div class="school box">
        <form action="school.php" id="form" method="POST" align="center">
        <br> <br>
            <h5 style="text-align: center;">Please Fill Up form to create School Account for a University</h5>
<br>
            <input type="text" id="schoolName" name="schoolName" style="width:35%" require placeholder="School Name "> <br> <br>
            <input type="text" id="schoolShortName" name="sShortName" style="width:35%" require placeholder="School Short Form "> <br> <br>
            <select name="uni" id="uni" style="width:35%; padding:5px">
                <option selected disabled>Select University</option>
                
            <?php
                $uniName = null;
                $q = "SELECT * from university";
                $query = mysqli_query($con, $q);
                while($travese = mysqli_fetch_array($query)){
                    echo "<option value = ".$travese['universityID'].">".$travese['universityName']."</option>";
                }
            ?>
            
            </select> <br> <br>

            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>
    </div>
    <div class="department box">
        <form action="#" id="form" method="POST" align="center">
        <br>
            <h5 style="text-align: center;">Please Fill Up form to create department Account for a University</h5> <br>

            <select name="university" id="university" style="width:35%; padding:5px">
                <option selected disabled>Select University</option>
                
            <?php
                
                $uniName = null;
                $q = "SELECT * from university";
                $query = mysqli_query($con, $q);
                while($travese = mysqli_fetch_array($query)){
                    echo "<option value = ".$travese['universityID'] .">".$travese['universityName']."</option>";
                }
            ?>
            </select> <br>     <br>       

            <div class="align-center">
                <input type="submit" id="form1" name="insert" class="btn but1 btn-primary text-white shadow" value="Submit" onclick="setValue()"/>
            </div>
        </form>
        
        <form action="department.php" id="form1div" class="content" align="center" style="padding:10px;margin-top:10px;" method="POST" >
        
                <input type="hidden" id="v" name ="v">
            <?php
                $uniN = "<script>document.write(p)</script>";
                $q = "SELECT * FROM university"; //WHERE universityName = '$uniN'
                $query = mysqli_query($con, $q);
                $uniid=null;

                while($travese = mysqli_fetch_array($query)){
                    if($travese['universityName'] == "Independent University, Bangladesh")
                    //if($travese['universityName'] === $uniN)
                    {
                        $uniid = $travese['universityID'];
                        $_SESSION['value'] = $uniid;
                        break;
                    }
                
                }
                //echo $uniid;
            ?>
            <select name="school" id="school" style="width:35%; padding:5px"><option value="null" selected disabled>Select school</option>
            <?php
                $q = "SELECT * from school WHERE universityID = '$uniid'";
                $query = mysqli_query($con, $q);
                while($travese = mysqli_fetch_array($query)){
                    echo "<option value = ".$travese['schoolID'].">".$travese['schoolName']."</option>";
                }
            ?>
            </select> <br> <br>
            <input type="text" name="deptName" style="width:35%" require placeholder="Department Name "> <br><br>
            <input type="text" name="deptShortName" style="width:35%" require placeholder="Department Short Name "> <br><br>
            <div>
                <input type="submit" class="btn btn-primary text-white shadow" value="Submit">
            </div>
        </form>
    </div>
</body>

</html>

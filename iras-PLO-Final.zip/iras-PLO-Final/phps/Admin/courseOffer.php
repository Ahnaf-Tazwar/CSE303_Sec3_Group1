<?php
    include '../../connection.php';
    
    $courseID =  $_POST['course'];
    $year =  $_POST['year'];
    $sem =  $_POST['sem'];
    $section =  $_POST['section'];
    $totalEnrollment =  $_POST['totalEnrollment'];
    $room =  $_POST['room'];
    $timing =  $_POST['timing'];
    $day =  $_POST['day'];
    $faculty = $_POST['faculty'];
    $invisilatorfaculty = $_POST['invisilatorfaculty'];
    $totalNumberOfStdent = 0;
    $enrollmentID = $courseID."_".$section."_".$sem."_".$year ;


    $insert = "INSERT INTO section(sectionID,courseID,year,semester,totalEnrollment,roomNo,classTime,day,
                            totalNumberOfStudent,facultyID,facultyIDModaretor,enrollmentID) 
                values('$section','$courseID','$year','$sem','$totalEnrollment','$room','$timing','$day',
                            '$totalNumberOfStdent','$faculty','$invisilatorfaculty','$enrollmentID')";
	mysqli_query($con, $insert);
    echo $enrollmentID;
?>
<script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>
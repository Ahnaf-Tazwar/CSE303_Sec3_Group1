<div class="slide_show">
    <?php 
       include 'admin.php'; 
    ?> 
</div>

<?php
    $universityID = $_SESSION['value'];
	$schoolID = $_POST['school'];
	$deptName = $_POST['deptName'];
	$deptShortName = $_POST['deptShortName'];
     
    $insert = "INSERT INTO department(deptShortName,deptName,schoolID,universityID) values('$deptShortName', '$deptName','$schoolID','$universityID')";
	mysqli_query($con, $insert);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .slide_show {
            display:none;
        }
        button{
            color: skyblue;
        }
        button a{
            text-decoration: none;
        }
    </style>
</head>
<body>
    <?php 
        // header('location: admin.php');
        // echo '        <script>      alert("Welcome to '.$school.'");       window.location.href="admin.php";         </script>';

    ?>
    <div align="center">
        <h1>Successfully Done. </h1>
        <button><a href="admin.php"> Okay </a></button>
    </div>

</body>
</html>

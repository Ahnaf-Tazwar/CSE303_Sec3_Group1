<?php
    include '../../connection.php';
    $fullname =  $_POST['fullname'];
    $shortname =  $_POST['shortname'];
    $dept = $_POST['dept'];
    
    $insert = "INSERT INTO program(programID,programName,deptShortName) values('$shortname','$fullname', '$dept')";
	mysqli_query($con, $insert);

?>
<script>
        alert("Successfully Done....!!!");
        window.location = 'uadmin.php';
    </script>
<?php
    $con = mysqli_connect('localhost','root');
    mysqli_select_db($con, 'spm');

	$name = $_POST['schoolName'];
	$shortname = $_POST['sShortName'];
	$uniid = $_POST['uni'];

	$insert = "INSERT INTO school(schoolID ,schoolName, universityID) 
                    values('$shortname', '$name','$uniid')";
	mysqli_query($con, $insert);
 ?>   
    <script>
        alert("Successfully Done....!!!");
        window.location = 'admin.php';
    </script>
<?php
include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Admin Page</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/logo1.png">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="stylesheet" href="adminStyle.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="adminStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>
    <script>
        $(document).ready(function() {
            $("#course_dropDown").change(function() {
                $(this).find("option:selected").each(function() {
                    var optionValue = $(this).attr("value");
                    if (optionValue) {
                        $(".box").not("." + optionValue).hide();
                        $("." + optionValue).show();
                    } else {
                        $(".box").hide();
                    }
                });
            }).change();
        });
    </script>
    <style>
        form {
            margin-top: 5%;
            margin-bottom: 5%;

        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Home</a>


        <div class="dropDownWrapper">
            <select id="course_dropDown" class="form-select">
                <option selected disabled> <i>Create Account </i></option>
                <option value="faculty"> Faculty Member Account</option>
                <option value="student"> Student Account</option>
                <option value="program"> Program Information</option>
                <option value="course"> Create Course</option>
                <option value="plo"> PLO Information</option>
                <option value="courseOffer"> Course Offer</option>
                <option value="courseRegistration"> Course Registration </option>
                <option value="updateResult"> Update Result </option>


            </select>
        </div>
        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">

            <ul class="navbar-nav ml-auto">
                <p align="right"> University Admin <br> Independent University, Bangladesh</p>
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>

        </div>
    </nav>

    <!-- faculty Account  -->
    <div class="faculty box content">
        <form action="faculty.php" id="form" method="POST" align="center">
            <h3 style="text-align: center;">Please Fill Up form to create Faculty Member Account</h3> <br>
            <input type="text" id="name" name="name" style="width:35%;padding: 5px;" required placeholder="Faculty Name "> <br> <br>
            <input type="text" id="fid" name="fid" style="width:35%;padding: 5px;" required placeholder="Faculty ID "> <br> <br>
            <input type="email" id="email" name="email" style="width:35%;padding: 5px;" required placeholder="Faculty email Address "> <br> <br>
            <input type="tel" id="phoneNo" name="phoneNo" style="width:35%;padding: 5px;" required placeholder="Faculty Contact No. "> <br> <br>

            <b>Date of Birth &nbsp &nbsp</b>
            <input type="date" id="dob" name="dob" style="width:27%;padding: 5px;" required placeholder="Date of Birth "> <br> <br>

            <b> Please select your gender: &nbsp &nbsp &nbsp
                <input type="radio" id="male" name="gender" value="male">
                <label for="male">Male &nbsp</label>
                <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female &nbsp</label>
                <input type="radio" id="other" name="gender" value="other">
                <label for="other">Other &nbsp</label>
            </b>
            <br>

            <select name="dept" id="dept" style="width:35%; padding:5px" required>
                <option selected disabled>Select Department </option>

                <?php

                $uniName = null;
                $q = "SELECT * from department";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['deptShortName'] . ">" . $travese['deptName'] . "</option>";
                }
                ?>
            </select> <br> <br>


            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>

    </div>

    <!-- Student Account  -->
    <div class="student box content">
        <form action="student.php" id="form" method="POST" align="center">
            <h3 style="text-align: center;">Please Fill Up form to create Student Account</h3> <br>
            <input type="text" id="fname" name="fname" style="width:17%;padding: 5px;" required placeholder="Student First Name "> &nbsp
            <input type="text" id="lname" name="lname" style="width:17%;padding: 5px;" required placeholder="Student Last Name "> <br> <br>

            <select name="sem" id="sem" style="width:17%; padding:5px" required placeholder="Admission Semester">
                <option value="Autumn">Autumn</option>;
                <option value="Summer">Summer</option>;
                <option value="Spring">Spring</option>;

            </select> &nbsp

            <input type="text" id="year" name="year" style="width:17%;padding: 5px;" required placeholder="admission Year "> <br> <br>

            <input type="text" id="sid" name="sid" style="width:35%;padding: 5px;" required placeholder="Student ID "> <br> <br>
            <input type="email" id="email" name="email" style="width:35%;padding: 5px;" required placeholder="Student email Address "> <br> <br>
            <input type="tel" id="phoneNo" name="phoneNo" style="width:35%;padding: 5px;" required placeholder="Student Contact No. "> <br> <br>

            <b>Date of Birth</b>
            <input type="date" id="dob" name="dob" style="width:27%;padding: 5px;" required placeholder="Date of Birth "> <br> <br>

            <b> Please select your gender: &nbsp &nbsp &nbsp
                <input type="radio" id="male" name="gender" value="male">
                <label for="male">Male &nbsp</label>
                <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female &nbsp</label>
                <input type="radio" id="other" name="gender" value="other">
                <label for="other">Other &nbsp</label>
            </b>
            <br>

            <select name="program" id="program" style="width:35%; padding:5px" required>
                <option selected disabled>Select Program </option>
                <?php

                $uniName = null;
                $q = "SELECT * from program";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['programID'] . ">" . $travese['programName'] . "</option>";
                }
                ?>
            </select> <br> <br>


            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>

    </div>

    <!-- Program Information  -->
    <div class="program box content">
        <form action="program.php" id="form" method="POST" align="center">
            <h3 style="text-align: center;">Please Fill Up form to set up Program Information</h3> <br>
            <select name="dept" id="dept" style="width:35%; padding:5px">
                <option selected disabled>Select Department </option>

                <?php

                $uniName = null;
                $q = "SELECT * from department";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['deptShortName'] . ">" . $travese['deptName'] . "</option>";
                }
                ?>
            </select> <br> <br>

            <input type="text" id="fullname" name="fullname" style="width:35%;padding: 5px;" required placeholder="Program Full Name "> <br> <br>
            <input type="text" id="shortname" name="shortname" style="width:35%;padding: 5px;" required placeholder="Program Short Name "> <br> <br>


            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>

    </div>


    <!-- Course Infomration  -->
    <div class="course box content">
        <form action="course.php" id="form" method="POST" align="center">
            <h3 style="text-align: center;">Please Fill Up form to Upload Course Information </h3> <br>
            <input type="text" id="courseID" name="courseID" style="width:35%;padding: 5px;" required placeholder="Course ID "> <br> <br>
            <input type="text" id="name" name="name" style="width:35%;padding: 5px;" required placeholder="Course Name "> <br> <br>
            <input type="number" id="noOfCredit" name="noOfCredit" style="width:35%;padding: 5px;" required placeholder="Number of Credit " min="1" max="4"> <br> <br>
            <input type="text" id="description" name="description" style="width:35%;padding: 5px;" required placeholder="Course description "> <br> <br>

            <select name="program" id="program" style="width:35%; padding:5px" required>
                <option selected disabled>Select Program</option>

                <?php

                $q = "SELECT * from program";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['programID'] . ">" . $travese['programName'] . "</option>";
                }
                ?>
            </select> <br> <br>

            <select name="pro" id="pro" style="width:35%; padding:5px">
                <option selected disabled>Select prequisite_1 </option>
                <option value="none">None</option>

                <?php

                $q = "SELECT * from course";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['courseID'] . ">" . $travese['courseName'] . "</option>";
                }
                ?>
            </select> <br> <br>

            <select name="pri" id="pri" style="width:35%; padding:5px">
                <option selected disabled>Select prequisite_2 </option>
                <option value="none">None</option>
                <?php

                $q = "SELECT * from course";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['courseID'] . ">" . $travese['courseName'] . "</option>";
                }
                ?>
            </select> <br> <br>


            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>

    </div>

    <!-- PLO Set Information Infomration  -->
    <div class="plo box content">
        <form action="plo.php" id="form" method="POST" align="center">
            <h3 style="text-align: center;">Please Fill Up form to set up PLO Information</h3> <br>
            <select name="program" id="program" style="width:17%; padding:5px" required>
                <option selected disabled>Select Program </option>
                <?php

                $q = "SELECT * from program";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['programID'] . ">" . $travese['programName'] . "</option>";
                }
                ?>
            </select> &nbsp

            <select name="plo" id="plo" style="width:17%; padding:5px">
                <option selected disabled>Select PLO ID </option>

                <?php
                $id = 1;
                while ($id < 13) {
                    echo "<option value = " . $id . ">" . $id . "</option>";
                    $id++;
                }
                ?>
            </select> <br> <br>

            <input type="text" id="name" name="name" style="width:35%;padding: 5px;" required placeholder="PLO Name "> <br> <br>
            <input type="text" id="details" name="details" style="width:35%;padding: 5px;" required placeholder="PLO Details "> <br> <br>
            <select name="ploLevel" style="width:35%; padding:5px">
                <option selected disabled>Select PLO Level </option>

                <?php
                $id = 1;
                while ($id < 7) {
                    echo "<option value = " . $id . ">" . $id . "</option>";
                    $id++;
                }
                ?>
            </select> <br> <br>

            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>
    </div>

    <!-- Course OFfer Infomration  -->
    <div class="courseOffer box content">
        <form action="courseOffer.php" id="form" method="POST" align="center">
            <h3 style="text-align: center;">Please Fill Up form to set up Course Offer Information</h3> <br>

            <select name="course" style="width:17%; padding:5px" required>
                <option selected disabled>Select Course </option>
                <?php

                $q = "SELECT * from course";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['courseID'] . ">" . $travese['courseName'] . "</option>";
                }
                ?>
            </select> &nbsp

            <select name="year" style="width:17%; padding:5px">
                <option selected disabled>Select Year </option>

                <?php
                $id = $y;
                echo "<option value = " . $id . ">" . $id . "</option>";
                ?>
            </select> <br> <br>

            <select name="sem" id="sem" style="width:17%; padding:5px" required placeholder="Admission Semester">
                <option selected disabled>Select Semester </option>
                <?php
                $id = $sem;
                echo "<option value = " . $id . ">" . $id . "</option>";
                ?>
                <!-- <option value = "Autumn">Autumn</option>;
            <option value = "Summer">Summer</option>;
            <option value = "Spring">Spring</option>; -->
            </select> &nbsp

            <select name="section" style="width:17%; padding:5px">
                <option selected disabled>Select Section </option>

                <?php
                $id = 1;
                while ($id < 16) {
                    echo "<option value = " . $id . ">" . $id . "</option>";
                    $id++;
                }
                ?>
            </select> <br> <br>

            <select name="totalEnrollment" style="width:17%; padding:5px">
                <option selected disabled>Select Total Capacity </option>
                <?php
                $id = 10;
                while ($id < 51) {
                    echo "<option value = " . $id . ">" . $id . "</option>";
                    $id++;
                }
                ?>
            </select> &nbsp
            <input type="text" name="room" style="width:17%;padding: 5px;" required placeholder="Room Number "> <br> <br>

            <select name="timing" style="width:17%; padding:5px" required placeholder="">
                <option selected disabled>Select Timing of the course </option>
                <option value="8:00-9:30">8:00-9:30</option>;
                <option value="9:30-11:00 ">9:30-11:00 </option>;
                <option value="11:00-12:30 ">11:00-12:30 </option>;
                <option value="12:30-14:00">12:30-14:00</option>;
                <option value="14:00-15:30 ">14:00-15:30 </option>;
                <option value="15:30-17:00 ">15:30-17:00 </option>;
                <option value="17:00-18:30  ">17:00-18:30 </option>;
                <option value="18:30-21:30">18:30-21:30</option>;
            </select> &nbsp

            <select name="day" style="width:17%; padding:5px" required placeholder="Class Day">
                <option selected disabled>Select Class Day</option>
                <option value="ST">Saturday Tuesday</option>;
                <option value="MW">Monday Wednesday</option>;
            </select> <br> <br>
            <select name="faculty" style="width:17%; padding:5px" required>
                <option selected disabled>Select faculty </option>
                <?php

                $q = "SELECT * from faculty";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['facultyID'] . ">" . $travese['facultyName'] . "</option>";
                }
                ?>
            </select> &nbsp

            <select name="invisilatorfaculty" style="width:17%; padding:5px" required>
                <option selected disabled>Select faculty Moderator </option>
                <?php

                $q = "SELECT * from faculty";
                $query = mysqli_query($con, $q);
                while ($travese = mysqli_fetch_array($query)) {
                    echo "<option value = " . $travese['facultyID'] . ">" . $travese['facultyName'] . "</option>";
                }
                ?>
            </select> <br><br>


            <div class="align-center">
                <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
            </div>
        </form>
    </div>
    <!-- Course Registration Activities  -->
    <div class="courseRegistration box content">
        <form action="courseRegistration.php" method="POST" style="display: block;">
            <h5 style="text-align: center;">Course Registration For Students</h5>
            <h5 style="text-align: center; color: blue;">For <?php echo $sem." ".$y; ?></h5> <br> <br>
            <p></p>
            <input type="hidden" name="status" id="statusID" value="false">
            <div align="center">
                <a href="#" onclick="startResigtration(); document.forms[6].submit(); " class="btn btn-primary text-white shadow">Start Registration</a>
                <a href="#" onclick="document.forms[6].submit();" class="btn btn-primary text-white shadow">Stop Registration</a>
            </div>
        </form>
    </div>
    <div class="updateResult box content">
        <form action="updateResult.php" method="POST" style="display: block;">
            <h5 style="text-align: center;">Update Result For Students</h5>
            <h5 style="text-align: center; color: blue;">For <?php echo $sem." ".$y; ?></h5> <br> <br>
            <p></p>
            <div align="center">
            <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Update" />
            </div>
        </form>
    </div>


</body>

</html>
<script>
    function startResigtration() {
        document.getElementById("statusID").value = "true";
    }
</script>
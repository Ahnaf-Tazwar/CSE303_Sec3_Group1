<?php
    include '../../connection.php';
    $sem = $_SESSION['semester'];
    $y = $_SESSION['year'];
    $id = $_SESSION['id'];
    $_SESSION['array'] = "";
   
    //$togglerID = "option_toggler1";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IRAS-PLO</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="facultyStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/logo1.png">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>


</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Home</a>

        <div class="dropDownWrapper">
            <select id="graph" class="form-select">
                <option selected disabled> <i>Select Options </i></option>
                <option value="course"> Course Information </option>
            </select>
        </div> &nbsp 

        
        
        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <p align="right"> <?php echo $_SESSION['name']; ?> <br> Independent University, Bangladesh </p>
                <div class="navbar-text ml-lg-3">
                    <a href="../../index.php" class="btn btn-primary text-white shadow">Sign out</a>
                </div>
            </ul>
        </div>
    </nav>

    <!-- <button onclick="counterIncrement()">This is for test</button> -->
    <div class="graphContainer">
        <div id="course" class="data">
            <br> <br>
            <form action="../Faculty/facultyCourseInformation.php" id="form" method="POST" align="center">
                <h2>Select courses </h2> <br> <br>
                <select name="course" style="width:35%; padding:5px">
                    <option selected disabled>Select Course</option>
                    
                <?php
                    $q = "SELECT * from section WHERE facultyID = '$id' AND year = '$y' AND semester = '$sem'";
                    $query = mysqli_query($con, $q);
                    while($travese = mysqli_fetch_array($query)){
                        echo "<option value = ".$travese['enrollmentID'] .">".$travese['courseID']."&nbsp &nbsp Section ".$travese['sectionID']."</option>";
                    }
                ?>
                </select> <br>     <br>       

                <div class="align-center">
                    <input type="submit" class="btn but1 btn-primary text-white shadow" value="Submit" />
                </div>
            </form>
        </div>

    </div>

    <script src="../../scripts/jquery.min.js"></script>    
    <script src="../../scripts/Chart.js"></script>
    <script>
        $(document).ready(function() {
            $("#graph").on('change', function() {
                //alert($(this).val());
                $(".data").hide();
                $("#" + $(this).val()).fadeIn(700);
            }).change();
        });



    </script>
</body>

</html>
<?php
include '../../connection.php';
$c = $_SESSION['course'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Questions</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="stylesheet" href="facultyStyle.css">
    <style>
        .content1{
            padding: 25px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">Make Questions</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="data">

                <a><button type="button" value="Quiz" onclick="setTitle(this.value)" class="btn btn-success but" id="contentLoader1">Quiz</button></a>
                <a><button type="button" value="Mid" onclick="setTitle(this.value)" class="btn btn-success but" id="contentLoader1">Mid - Term</button></a>
                <a><button type="button" value="Final" onclick="setTitle(this.value)" class="btn btn-success but" id="contentLoader1">Final - Term</button></a>
                <a><button type="button" value="Project" onclick="setTitle(this.value)" class="btn btn-success but" id="contentLoader1">Project</button></a>

            </div>

            <ul class="navbar-nav ml-auto">
                <p align="right"> <?php echo $_SESSION['name']; ?> <br> Independent University, Bangladesh</p>
                <div class="navbar-text ml-lg-3">
                    <a href="../Faculty/facultyCourseInformation.php" class="btn but1 btn-primary text-white shadow">Back</a>
                </div>
            </ul>

        </div>
    </nav>

    <form action="previewQuestions.php" id="contentLoader1div" class="content1" method="POST">
        <!--<label style="align-items: center;">Available PLOs for the course: </label>-->
        <input type="text" name="type" id="type" hidden >'
        <h5 style="text-align: center;" id="title">Exam</h5>
        <label for="">Enter Exam Duration: </label>
        <input type="number" name="hours" placeholder="Hours" required>
        <input type="number" name="minutes" placeholder="Minutes" required>
        <p>This are the prevous course outcome for semester Summer 2020 <a href="#">Past Paper 1</a> <a href="#">Past Paper 2</a> <a href="#">Past Paper 3</a></p>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Course Outome</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $q = "SELECT * FROM co WHERE enrollmentID = '$c'";
                $query = mysqli_query($con, $q);
                while ($t = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <?php
                        $co = $t['coID'];
                        $co = substr($co, 0, 1);
                        ?>
                        <td><?php echo $co; ?></td>
                        <td><?php echo $t['description'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <input type="text" id="courseID_input" hidden>
        <div class="input_fields_wrap">
            <div class="repeater-heading" align="center">
                <button type="button" class="btn btn-primary add_field_button repeater-add-btn" onclick="document.getElementById('closer').remove()">Add a question</button>
            </div>
            <div class="row CLO_Div">
                <div class="col-md-11">
                    <label for="course_description">
                        Write the question description below in details. Note: The following exam question will be saved as Question 1 &nbsp
                    </label>
                    <textarea name="questionDescription[]" id="course_description" required></textarea>
                    <select name="co[]" style="width:25%;padding: 5px;">
                        <option selected disabled> <i> Course Outcome </i></option>
                        <?php
                        $query = mysqli_query($con, $q);
                        while ($t = mysqli_fetch_array($query)) {
                            $co = $t['coID'];
                            $co = substr($co, 0, 1);
                            echo '<option value=' . $co . '> CO - '. $co . '</option>';
                        } ?>
                    </select>
                    <input type="number" name="total[]" style="width:15%;padding: 5px;" required placeholder="Marks "> 
                    <input type="text" name="sampleans[]" style="width:55%;padding: 5px;" required placeholder="Sample Answer "> 
                    <br>
                </div>
                <!-- <button id="closer" align="right" onclick="$(this).parents('.CLO_Div').remove()"></button> -->

            </div>
        </div>

        <div align="right">
            <!-- <a href="#" id="saveID" class="btn btn-primary text-white shadow">Submit</a> -->
            <a href="../Faculty/facultyCourseInformation.php"><button type="button"  style="width: 20%; height: 5vh;" class="btn btn-primary text-white shadow" >Cancel</button></a>
            <input type="submit" class="btn btn-primary text-white shadow" value="Preview" />
        </div>
    </form>

    <script>
        $(document).ready(function() {
            var x = 2; //initlal text box count
            var max_fields = 9; //maximum input boxes allowed
            var wrapper = $(".input_fields_wrap"); //Fields wrapper
            var add_button = $(".add_field_button"); //Add button ID


            var b = '"><div class="col-md-11"><label for="course_description">Write the question description below in details. Note: The following exam question will be saved as Question ';
            var c = '<p id="CLO_current_number"></p></label><textarea name="questionDescription[]" id="course_description" required></textarea>';
            var d = '</div><button class = "remove_field" align="right" id="closer"></button></div>';
            
            // <select name="co" style="width:25%;padding: 5px;">
            // echo '<option value=' . $co . '> CO - '. $co . '</option>';

            $(add_button).click(function(e) { 
                e.preventDefault();

                if (x <= max_fields) { //max input box allowed

                    //text box increment

                    var PLOArr = []
                    var f = '<select name="co[]" style="width:25%;padding: 5px;"> <option selected disabled> <i> Course Outcome </i></option>';
                    <?php 
                        $query = mysqli_query($con, $q);
                        while ($t = mysqli_fetch_array($query)) {
                        $co = $t['coID'];
                        $co = substr($co, 0, 1);
                    ?>
                    //for (var i = 1; i < 5; i++) {

                        //PLOArr.push('&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="checkbox" id = "' + x + i + '"name = "PLO[]">');
                        PLOArr.push('<option value=' + <?php echo $co; ?> + '> CO - ' + <?php echo $co; ?> + '</option>');
                    //}
                    <?php } ?>
                    var g = '</select> <input type="number" name="total[]" style="width:15%;padding: 5px;" required placeholder="Marks "> &nbsp';
                    var h = '<input type="text" name="sampleans[]" style="width:55%;padding: 5px;" required placeholder="Sample Answer "> ';
                    var a = '<div class="row CLO_Div" id = "list' + x;

                    $(wrapper).append(a + b + x + c + f + PLOArr.join("") + g + h + d);
                    //$(wrapper).append(x);

                    x++;
                }
            });


            $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
                e.preventDefault();

                if (x > 3) {
                    var newItem = document.createElement('BUTTON');
                    newItem.id = "closer";
                    newItem.className = "remove_field";


                    //var newX = x - 2;
                    str = "list" + (x - 2).toString();
                    var list = document.getElementById(str);

                    list.insertBefore(newItem, list.childNodes[1]);
                }

                $(this).parent('div').remove();


                if (x >= 2) {
                    x--;
                } else {
                    x = 1;
                }
            })
        });

        // function getCourseID(){
        //     var dropDownID = document.getElementById("course_dropDown");
        //     var courseID_Sec = dropDownID.options[dropDownID.selectedIndex];
        //     return courseID_Sec.value;
        // }
        function setTitle(val) {
            var val2 = "<?PHP echo $c; ?>";
            document.getElementById('title').innerHTML = val2 + "<br>" + val;
            document.getElementById("courseID_input").value = val2;
            document.getElementById("type").value = val;
        }

        $(function() {
            $(".but").on("click", function(e) {
                e.preventDefault();
                $(".contentLoader1").hide();
                $("#" + this.id + "div").fadeIn(700);
            });
        });
    </script>

</body>

</html>
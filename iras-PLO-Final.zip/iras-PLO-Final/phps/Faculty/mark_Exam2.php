<?php

include '../../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id'];
//$arr =  $_SESSION['array'];
if (isset($_POST['course'])) {
    $c = $_POST['course'];
} else {
    if (isset($arr[4])) {
        $c = $arr[4];
    } else {
        $c = $_SESSION['course'];
    }
}
// there is course id in $c
$_SESSION['course'] = $c;

$examID = isset($_POST['loadExam']) ? $_POST['loadExam'] : $_SESSION['exam'];

// echo $examID;
if ($examID == null) {
?>
    <script>
        alert("You must select an Exam to Load....!");
        window.location = "facultyCourseinformation.php";
    </script>
<?php
}

//this variable will load all the students attended on the following exam
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Exam 2</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="facultyStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>


</head>

<style>
    .tableStyle {
        background-color: whitesmoke;
        height: auto;
        display: block;
        margin: 5vh;
        border: 5px solid #746cc0;
    }

    p {
        font-size: 4vh;
    }
</style>

<body>

    <div id="" class="tableStyle" style="position: relative;">
        <p align="center"><strong><i>Marks of all terms that are taken for all the registered courses for this semester:</i></strong></p>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr align="center">
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Load Exam</th>
                </tr>
            </thead>
            <tbody align="center">
                <?php
                $value = "-9999";
                $q = "SELECT DISTINCT s.fname AS fname , s.lname AS lname, s.studentID AS id
                FROM student AS s, assessment AS a, question AS q, evaluation AS e 
                WHERE e.quesID=q.quesID AND q.assessmentID = a.assessmentID AND a.enrollmentID = '$c' AND a.nameOfAss = '$examID' AND e.studentID = s.studentID AND e.evaluationID NOT IN (SELECT evaluationID FROM evaluation_faculty)";


                $qu = mysqli_query($con, $q);
                $i = 0;
                while ($t = mysqli_fetch_assoc($qu)) {
                    echo "<tr>
                    <td>" . $t['id'] . "</td>
                    <td>" . $t['fname'] . " " . $t['lname'] . "</td>
                    <td>
                        <form action=\"mark_Exam3.php\" method=\"POST\">
                        <input type=\"hidden\" name = \"student\" value = " . $t['id'] . ">
                        <input type=\"hidden\" name = \"examID\" value = " . $examID . ">
                        <a href = \"#\" onclick=\"document.forms[" . $i . "].submit();return false;\" style = \"text-decoration: none; width: 30%;\"
                        class=\"btn btn-primary text-white shadow\">Load</a>
                        </form>
                    </td>

                </tr>";
                    $i++;
                }
                ?>

            </tbody>
        </table>
        <div align="center">
            <a href="../Faculty/facultyCourseInformation.php"><button type="button" style="width: 15%; height: 5vh; margin-bottom:2%" class="btn btn-primary text-white shadow">Cancel</button></a>
        </div>
    </div>






    <script>
        function startResigtration() {
            document.getElementById("statusID").value = "true";
        }
    </script>

</body>

</html>
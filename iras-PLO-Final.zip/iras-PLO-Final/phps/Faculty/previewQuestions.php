<?php
include '../../connection.php';
$c = $_SESSION['course'];


$questionArr = $_POST['questionDescription'];
$marks = $_POST['total'];
$sampleAns = $_POST['sampleans'];
$co = $_POST['co'];
$hours = $_POST['hours'];
$minutes = $_POST['minutes'];
$type = $_POST['type'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview Question</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="stylesheet" href="facultyStyle.css">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" id="navBar">
        <a class="navbar-brand" href="#">  <?php echo $c; ?> </a>

        <p>&nbsp&nbsp&nbsp</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <div class="navbar-text ml-lg-3">
                    <a href="../Faculty/makeQuestions.php" class="btn btn-primary text-white shadow"> Back </a>
                </div>
            </ul>
        </div>
    </nav>

    <!-- this is preview -->
    <form action="examUploader.php" id="contentLoader1div" class="content3" style="display: block;" method="POST">
    <br>
        <h5 style="text-align: center;" id="title">Question Paper Preview</h5>
        &nbsp &nbsp  &nbsp<?php echo "Total Time: ".$hours.":".$minutes." Hours";?>
        <?php 
            echo '<input type="text" name="hours" value='.$hours.' hidden >';
            echo '<input type="text" name="minutes" value='.$minutes.' hidden >';
            echo '<input type="text" name="type" value='.$type.' hidden >';

        ?>
        <div class="input_fields_wraps">
            <div class="row CLO_Div">
                <div class="col-md-11">
                    <?php
                    for ($y = 0; $y < count($questionArr); $y++) {
                        echo '<textarea name="questionDescription[]" hidden>' . $questionArr[$y] . '</textarea>';
                        echo '<input type="number" name="total[]" value="'.$marks[$y].'" hidden >';
                        echo '<input type="text" name="sampleans[]" value="'.$sampleAns[$y].'"hidden >';
                        echo '<input type="text" name="co[]" value="'.$co[$y].'" hidden >';
                        


                        echo '<label for="course_description">
                                <b>Question ' . ($y + 1) . '</b> </label> <br>';
                        echo "Question Details: ";
                        echo $questionArr[$y];
                        echo "<br>Course Outcome: ".$co[$y] ;
                        echo "<br>";
                        echo "Marks: ".$marks[$y];
                        echo "<br>";
                        echo "Sample Answer: ".$sampleAns[$y];
                        echo "<br> <br>";
                    }
                    ?>

                </div>

            </div>
        </div>
        &nbsp 
        &nbsp 
        &nbsp 
        EXAM Date: &nbsp
        <input type="date" name="date" style="width:15%;padding: 5px;" required> 
        &nbsp &nbsp  EXAM Time: &nbsp
        <input type="time" name="time" style="width:15%;padding: 5px;" required> 
        <div align="right" style="margin-right:15px; margin-bottom:10px;">
            <input type="submit" name="insert" class="btn btn-primary text-white shadow" value="Submit" />
        </div>
    </form>


   

</body>

</html>
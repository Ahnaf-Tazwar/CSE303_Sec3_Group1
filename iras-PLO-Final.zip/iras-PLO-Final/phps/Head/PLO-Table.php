<?php
    include '../../connection.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/logo1.png">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="../admin/adminStyle.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>
    <script>
        $(document).ready(function(){
            $("#course_dropDown").change(function(){
                $(this).find("option:selected").each(function(){
                    var optionValue = $(this).attr("value");
                    if(optionValue){
                        $(".box").not("." + optionValue).hide();
                        $("." + optionValue).show();
                    } else{
                        $(".box").hide();
                    }
                });
            }).change();
        });
      
        function setValue(){
            a = document.getElementById("course").selectedIndex;
            x = document.getElementById("course").options[a].value;
            res = x.slice(3,4);
        }
      
    // load edit
    $(function() {
        $(".but1").on("click", function(e) {
            e.preventDefault();
            $("#" + this.id + "div").fadeIn(700);
            trigger("form1");
        });
    });

    function trigger(val) {
        var id = document.getElementById(val);
        if (id.style.display === "none") {
            id.style.display = "block";
        } else {
            id.style.display = "none";
        }
    }
    </script>
    <style>
        
    </style>
</head>

<body>
    <h1 align="center">Set PLO and Course Mapping </h1>
    
    <div>
        <form action="#" id="form" method="POST" align="center">
          
            <select name="course" id="course" style="width:35%; padding:5px">
                <option selected disabled>Select Course</option>
                
            <?php
                $q = "SELECT * from course";
                $query = mysqli_query($con, $q);
                while($travese = mysqli_fetch_array($query)){
                    echo "<option value = ".$travese['courseID'] .">".$travese['courseName']."</option>";
                }
            ?>
            </select> <br>     <br>       

            <div class="align-center">
                <input type="submit" id="form1" name="insert" class="btn but1 btn-primary text-white shadow" value="Submit" onclick="setValue()"/>
            </div>
        </form>
        
        <form action="#" id="form1div" class="content" align="center" style="padding:10px;margin-top:10px;" method="POST" >
        
            <?php
                $uniN = "<script>document.write(res)</script>";
                echo $uniN;
                $q = "SELECT * FROM university"; //WHERE universityName = '$uniN'
                $query = mysqli_query($con, $q);
                $uniid=null;

                while($travese = mysqli_fetch_array($query)){
                    if($travese['universityName'] == "Independent University, Bangladesh")
                    //if($travese['universityName'] === $uniN)
                    {
                        $uniid = $travese['universityID'];
                        $_SESSION['value'] = $uniid;
                        break;
                    }
                
                }
                //echo $uniid;
            ?>
            <select name="school" id="school" style="width:35%; padding:5px"><option value="null" selected disabled>Select school</option>
            <?php
                $q = "SELECT * from school WHERE universityID = '$uniid'";
                $query = mysqli_query($con, $q);
                while($travese = mysqli_fetch_array($query)){
                    echo "<option value = ".$travese['schoolID'].">".$travese['schoolName']."</option>";
                }
            ?>
            </select> <br> <br>
            <input type="text" name="deptName" style="width:35%" require placeholder="Department Name "> <br><br>
            <input type="text" name="deptShortName" style="width:35%" require placeholder="Department Short Name "> <br><br>
            <div>
                <input type="submit" class="btn btn-primary text-white shadow" value="Submit">
            </div>
        </form>
    </divclass=>
</body>

</html>

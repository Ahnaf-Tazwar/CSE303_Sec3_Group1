<?php
    include '../../connection.php';
    
    $c =  $_POST['cou'];
    $_SESSION['c'] = $c;
    $course = substr($c, 3,1);
    if($course == 1){
        $label = 4;
    }
    else if($course == 2){
        $label = 5;
    }
    else if($course == 3){
        $label = 6;
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboardStyle.css">
    <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="facultyStyle.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../images/logo1.png">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script> -->
    <!-- <script src="https://cdn.linearicons.com/free/1.0.0/svgembedder.min.js"></script> -->


    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

    <script src="../../scripts/repeater.js"></script>
    <title>PLO Mapping </title>
</head>
<body>
<br> <br>
    <form action="ploMappingInsert.php" id="form" method="POST" align="center">
        <?php
            $q = "SELECT * FROM course AS c WHERE c.courseID = '$c'"; 
            $query = mysqli_query($con, $q);
            $travese = mysqli_fetch_array($query);
            $cName = $travese['courseName'];
            $courseDescription = $travese['courseDescription'];
        ?>

        <h2>Select PLO For <?php echo $cName?></h2> <br>
        <p><b>Course Description: </b><?php echo $courseDescription?></p> <br> <br>

        <select name="plo1" style="width:17%; padding:5px">
            <option selected disabled>Select PLO </option>
            
        <?php
            $q = "SELECT * FROM plo AS p WHERE p.lavel <= '$label'"; 
            $query = mysqli_query($con, $q);
            while($travese = mysqli_fetch_array($query)){
                echo "<option value = ".$travese['ploID'] .">".$travese['ploID'].". ". $travese['name']."</option>";
            }
        ?>
        </select>     &nbsp &nbsp
        
        <select name="plo2" style="width:17%; padding:5px">
            <option selected disabled>Select PLO </option>
            
        <?php
            $q = "SELECT * FROM plo AS p WHERE p.lavel <= '$label'"; 
            $query = mysqli_query($con, $q);
            while($travese = mysqli_fetch_array($query)){
                echo "<option value = ".$travese['ploID'] .">".$travese['ploID'].". ". $travese['name']."</option>";
            }
        ?>
        </select> <br> <br>
        <select name="plo3" style="width:17%; padding:5px">
            <option selected disabled>Select PLO </option>
            
        <?php
            $q = "SELECT * FROM plo AS p WHERE p.lavel <= '$label'"; 
            $query = mysqli_query($con, $q);
            while($travese = mysqli_fetch_array($query)){
                echo "<option value = ".$travese['ploID'] .">".$travese['ploID'].". ". $travese['name']."</option>";
            }
        ?>
        </select>     &nbsp &nbsp
        
        <select name="plo4" style="width:17%; padding:5px">
            <option selected disabled>Select PLO </option>
            
        <?php
            $q = "SELECT * FROM plo AS p WHERE p.lavel <= '$label'"; 
            $query = mysqli_query($con, $q);
            while($travese = mysqli_fetch_array($query)){
                echo "<option value = ".$travese['ploID'] .">".$travese['ploID'].". ". $travese['name']."</option>";
            }
        ?>
        </select> <br> <br>


        <div class="align-center">
            <input type="submit" id="form1" name="insert" class="btn but1 btn-primary text-white shadow" value="Submit" onclick="setValue()"/>
            <a href="dashboard_head.php" class="btn but1 btn-primary text-white shadow">Cancel</a>
        </div>
    </form>
</body>
</html>

<!-- <script>
        alert("Successfully Done....!!!");
        window.location = 'dashboard_Head.php';
    </script> -->
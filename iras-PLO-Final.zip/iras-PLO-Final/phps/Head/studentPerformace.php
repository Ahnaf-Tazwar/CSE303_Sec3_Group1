<?php
    include '../../connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Enrollment Graph </title>
    <script src="../../scripts/jquery.min.js"></script>    
    <script src="../../scripts/Chart.js"></script>
    <style>
        div{
            
            margin-top: 10%;
            margin-left: 20%;
        }
        button{
            margin-top: 2%;
            margin-left: 70%;
            background: #87CEEB;
            
        }
    </style>
</head>
<body>
    <div style="width: 50% ">
        <canvas id="myChart" style="width: 500px"></canvas>
    </div>
    <button><a href="dashboard_Head.php">Back</a></button>
</body>
</html>
<?php
    $year = $_POST['year'];
    $ycpArr = array();
    $q = "SELECT * from student";
    $query = mysqli_query($con, $q);
    $count =0;
    while($traverse = mysqli_fetch_array($query)){
        if($traverse['semester'] == 'Spring' && $traverse['year'] == $year)
            $count++;
    }
    array_push($ycpArr, $count);
    $query = mysqli_query($con, $q);
    $count1 =0;
    while($traverse = mysqli_fetch_array($query)){
        if($traverse['semester'] == 'Summer' && $traverse['year'] == $year )
            $count1++;
    }
    array_push($ycpArr, $count1);
    $query = mysqli_query($con, $q);
    $count2 =0;
    while($traverse = mysqli_fetch_array($query)){
        if($traverse['semester'] == 'Autumn' && $traverse['year'] == $year)
            $count2++;
    }
    array_push($ycpArr, $count2);
?>

<script>
    var obj4 = <?php echo json_encode($ycpArr); ?>;
</script>

<script>
    var obj = ["Spring", "Summer", "Autumn"];


    function BuildChart(labels, values, chartTitle) {
        var ctx = document.getElementById("myChart").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels, // Our labels
                datasets: [{
                    label: chartTitle, // Name the series
                    data: values, // Our values
                    backgroundColor: [ // Specify custom colors
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 0.5)',
                        'rgba(255, 206, 86, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(153, 102, 255, 0.5)',
                        'rgba(255, 159, 64, 0.5)'
                    ],
                    borderColor: [ // Add custom color borders
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1 // Specify bar border width
                }]
            },
            options: {
                responsive: true, // Instruct chart js to respond nicely.
                maintainAspectRatio: false, // Add to prevent default behavior of full-width/height 
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }

            }
        });
        return myChart;
    }
    var chart2 = BuildChart(obj, obj4, "Semester wise Student's trends on Admission");

</script>



<?php
session_start();


$One = "One";
$Two = "Two";
$Three = "Three";
$Four = "Four";
$Five = "Five";

$isExam = false;
//$isExam = true;
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IRAS-PLO</title>
  <link rel="stylesheet" href="../css/dashboardStyle.css">
  <!-- <link rel="stylesheet" href="../../css/bootstrap.min.css"> -->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="studentStyle.css">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>


  <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

  <script src="../scripts/jquery.min.js"></script>
  <script src="../scripts/Chart.js"></script>


</head>

<body>











  <div style="background-color: whitesmoke;">
    <canvas id="myChart" style="width: 20vw; height: 20vw;"></canvas>
  </div>







  <script>
    var obj = ["Autumn 2020", "Summer2020", "Spring 2020", "Autumn 2021"];
    var obj2 = ["2.97", "2.35", "3.68", "3.25"];


    function BuildChart2(labels, values, chartTitle) {
      var ctx = document.getElementById("myChart").getContext('2d');
      var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels, // Our labels
          datasets: [{
            label: chartTitle, // Name the series
            data: values, // Our values
            fill: false,
            backgroundColor: [ // Specify custom colors
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [ // Add custom color borders
              'rgba(255,99,132,1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1 // Specify bar border width
          }]
        },
        options: {
          responsive: true, // Instruct chart js to respond nicely.
          maintainAspectRatio: false, // Add to prevent default behavior of full-width/height 
          scales: {

            xAxes: [{
              scaleLabel: {
                display: true,
                labelString: 'Semesters',

              }
            }],

            yAxes: [{
              ticks: {
                beginAtZero: true
              },
              scaleLabel: {
                display: true,
                labelString: 'Average CGPA'
              }
            }]
          }

        }
      });
      return myChart;
    }
    var chart2 = BuildChart2(obj, obj2, "Semester wise CGPA performance");
  </script>

  <!-- <script src="../../scripts/graph.Loader.js"></script> -->
</body>

</html>
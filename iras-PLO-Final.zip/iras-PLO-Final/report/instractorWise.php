<html>
    <head>
        <title>This is SPM </title>
</head>
<body>
     <navbar class="bg-info"><div align = "right" class="mr-5">DR Mahady Hasan<br> Independent University, Bangladesh</div></navbar>
     
     <div align="center"> Course Name: <?php echo"CSE303+L"?></div><br><br>
    <div class="bg-info" align="center">
   <b>choose your Graph : </b>
   <br>
   <!-- <input class = "" type="number" placeholder="1731407" ><br><br> -->
   <form action="instractorWise.php" method="POST">
   <select id="course_dropDown" class="form-select" name="select">
                <option selected disabled> <i>Chart List </i></option>
                <option value="LineChart"> LineChart</option>
                <option value="PieChart"> PieChart</option>
                <option value="BarChart"> BarChart</option>
                <option value="RadarChart"> RadarChart</option>

    </select>
    <!-- <script>
    document.getElementsByName('select')[0].value = '<?php echo $_POST['select']; ?>'
</script> -->
    <input type="submit" name="submit" onclick="drawChart()"> 
    </form>

     <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
     var data = new google.visualization.DataTable();
        data.addColumn('string', 'PLO');
        data.addColumn('number', 'PLO-Achievement');
        for(i = 0; i < obj.length; i++)
            data.addRow([obj[i][0],parseInt(obj[i][1])]);
        // Set chart options
        var options = {'title':'Student Id-wise Course Performance',
                       'width':600,
                       'height':500,
			   is3D:true,};


        var chart = new google.visualization.<?php echo $structure ;?>(document.getElementById('chart_div'));
        chart.draw(data, options);
      
</script>
<div>
<div class="" align="center" id="chart_div"></div>

</div>

</body>
</html>
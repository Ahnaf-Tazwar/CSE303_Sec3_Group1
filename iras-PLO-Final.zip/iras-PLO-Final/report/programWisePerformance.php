<html>

<head>
    <style>
        body {
            background: url('https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.pngitem.com%2Fpimgs%2Fm%2F513-5131515_website-background-design-illustration-hd-png-download.png&imgrefurl=https%3A%2F%2Fwww.pngitem.com%2Fmiddle%2FhwmxJbJ_website-background-design-illustration-hd-png-download%2F&tbnid=WDIZBDAfMo1CpM&vet=12ahUKEwihnr6grcPwAhVUk0sFHZsGDh4QMyhlegUIARDNAQ..i&docid=MdUD25U9TzXpBM&w=860&h=496&q=background%20image%20for%20website&ved=2ahUKEwihnr6grcPwAhVUk0sFHZsGDh4QMyhlegUIARDNAQ');
        }
    </style>

</head>

<body>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 px-5 mr-3" align="center">
                    <div id="container"></div>
                </div>
            </div>
        </div>
    </section>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        anychart.onDocumentReady(function() {
                    // create data set on our data
                    var dataSet = anychart.data.set([
                        ['PLO1', 67, 78],
                        ['PLO2', 82, 78],
                        ['PLO3', 66, 0],
                        ['PLO4', 79, 83],
                        ['PLO5', 0, 59],
                        ['PLO6', 69, 0],
                        ['PLO7', 0, 0],
                        ['PLO8', 0, 0],
                        ['PLO9', 0, 65],
                        ['PLO10', 79, 0],
                        ['PLO11', 0, 0],
                        ['PLO12', 68, 0],
                        // ['Spirit', 158, 64, 196]
                    ]);

                    // map data for the first series, take x from the zero column and value from the first column of data set
                    var data1 = dataSet.mapAs({
                        x: 0,
                        value: 1
                    });
                    // map data for the second series, take x from the zero column and value from the second column of data set
                    var data2 = dataSet.mapAs({
                        x: 0,
                        value: 2
                    });
                    // map data for the third series, take x from the zero column and value from the third column of data set
                    // var data3 = dataSet.mapAs({ x: 0, value: 3 });

                    // create radar chart
                    var chart = anychart.radar();

                    // set chart title text settings
                    chart.title(
                        'Student Id Wise Performance into a Semester: ' + '<?php echo "Summer"; ?>'
                    );

                    // set chart yScale settings
                    chart.yScale().minimum(0).maximumGap(0).ticks().interval(50);

                    // set xAxis labels settings
                    chart.xAxis().labels().padding(5);

                    // set chart legend settings
                    chart.legend().align('center').enabled(true);


                    // create first series with mapped data
                    var series1 = chart.line(data1).name('CSE');

                    series1.markers().enabled(true).type('circle').size(4);
                    // create first series with mapped data
                    var series2 = chart.line(data2).name('CS');
                    series2.markers().enabled(true).type('circle').size(3);
                    // create first series with mapped data
                    // var series3 = chart.line(data3).name('Priest');
                    // series3.markers().enabled(true).type('circle').size(3);

                    // chart tooltip format
                    chart.tooltip().format('Value: {%Value}');

                    // set container id for the chart
                    chart.container('container');
                    chart.draw();
                });
    </script>


</body>

</html>
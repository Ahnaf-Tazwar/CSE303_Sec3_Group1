<?php
include '../connection.php';
$sem = $_SESSION['semester'];
$y = $_SESSION['year'];
$id = $_SESSION['id'];
$pusherID = array();
$pusherValue = array();

for ($i = 1; $i <= 12; $i++) {
  $w = rand(1,5);
  $q = "SELECT SUM(e.obatinMarks) * ($i * $w * 10)/ SUM(q.mark) as total FROM plocomapping AS p, co as c, registration as r, 
    question as q, department as d, program as pr, course as cr, section as s, evaluation as e
    where p.ploID = '$i' AND p.coID = c.coID AND c.enrollmentID = r.enrollmentID AND d.deptShortName = pr.deptShortName 
    and pr.programID = cr.programID AND cr.courseID = s.courseID AND s.enrollmentID = e.enrollmentID AND 
    e.quesID = q.quesID GROUP BY p.ploID";
    $q = mysqli_query($con, $q);
    $t = $q->fetch_assoc();
    array_push($pusherID, $i);
    echo $t['total']."<br>";
    array_push($pusherValue, $t['total']);
}

?>

<html>

<head>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-radar.min.js"></script>
  <link href="https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css" type="text/css" rel="stylesheet">
  <link href="https://cdn.anychart.com/releases/v8/fonts/css/anychart-font.min.css" type="text/css" rel="stylesheet">
  <style type="text/css">
    html,
    body,
    #container {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
    }
  </style>
</head>

<body>


  <div id="container"></div>


  <script>
  var ploID = <?php echo json_encode($pusherID); ?>;
  var plovalue = <?php echo json_encode($pusherValue); ?>;
  
    anychart.onDocumentReady(function() {
      // create data set on our data
      var dataSet = anychart.data.set([
        ['PLO1', plovalue[0], 0],
        ['PLO2', plovalue[1], 0],
        ['PLO3', plovalue[2], 0],
        ['PLO4', plovalue[3], 0],
        ['PLO5', plovalue[4], 0],
        ['PLO6', plovalue[5], 0],
        ['PLO7', plovalue[6], 0],
        ['PLO8', plovalue[7], 0],
        ['PLO9', plovalue[8], 0],
        ['PLO10', plovalue[9], 0],
        ['PLO11', plovalue[10], 0],
        ['PLO12', plovalue[11], 0],
        // ['Spirit', 158, 64, 196]
      ]);

      // map data for the first series, take x from the zero column and value from the first column of data set
      var data1 = dataSet.mapAs({
        x: 0,
        value: 1
      });
      // map data for the second series, take x from the zero column and value from the second column of data set
      var data2 = dataSet.mapAs({
        x: 0,
        value: 2
      });
      // map data for the third series, take x from the zero column and value from the third column of data set
      // var data3 = dataSet.mapAs({ x: 0, value: 3 });

      // create radar chart
      var chart = anychart.radar();

      // set chart title text settings
      chart.title(
        'School Wise Performance into a Semester: ' + '<?php echo "Summer"; ?>'
      );

      // set chart yScale settings
      chart.yScale().minimum(0).maximumGap(0).ticks().interval(50);

      // set xAxis labels settings
      chart.xAxis().labels().padding(5);

      // set chart legend settings
      chart.legend().align('center').enabled(true);


      // create first series with mapped data
      var series1 = chart.line(data1).name('SEMESTER: SUMMER');
      '<br>';
      var series1 = chart.line(data1).name('Points');
      series1.markers().enabled(true).type('circle').size(4);
      // create first series with mapped data
      // var series2 = chart.line(data2).name('BBA');
      // series2.markers().enabled(true).type('circle').size(3);
      // create first series with mapped data
      // var series3 = chart.line(data3).name('Priest');
      // series3.markers().enabled(true).type('circle').size(3);

      // chart tooltip format
      chart.tooltip().format('Value: {%Value}');

      // set container id for the chart
      chart.container('container');
      chart.draw();
    });
  </script>
</body>

</html>
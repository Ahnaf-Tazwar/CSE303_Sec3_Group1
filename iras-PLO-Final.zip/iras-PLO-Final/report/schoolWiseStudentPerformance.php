<html>
<head>
<style>
body{
    background:url('https://www.google.com/imgres?imgurl=https%3A%2F%2Fwww.pngitem.com%2Fpimgs%2Fm%2F513-5131515_website-background-design-illustration-hd-png-download.png&imgrefurl=https%3A%2F%2Fwww.pngitem.com%2Fmiddle%2FhwmxJbJ_website-background-design-illustration-hd-png-download%2F&tbnid=WDIZBDAfMo1CpM&vet=12ahUKEwihnr6grcPwAhVUk0sFHZsGDh4QMyhlegUIARDNAQ..i&docid=MdUD25U9TzXpBM&w=860&h=496&q=background%20image%20for%20website&ved=2ahUKEwihnr6grcPwAhVUk0sFHZsGDh4QMyhlegUIARDNAQ');
}
</style>

</head>
<body>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<div class="bg-info" align="center">
   <b>Enter Your Student ID</b>
   <!-- <input class = "" type="number" placeholder="1731407" ><br><br>
   <form action="studentPerformance(Faculty).php" method="POST">
   <select id="course_dropDown" class="form-select" name="select">
                <option selected disabled> <i>Chart List </i></option>
                <option value="LineChart"> LineChart</option>
                <option value="PieChart"> PieChart</option>
                <option value="BarChart"> BarChart</option>
                <option value="RadarChart"> RadarChart</option>

    </select> -->
    <!-- <script>
    document.getElementsByName('select')[0].value = '<?php echo $_POST['select']; ?>'
</script> -->
    <!-- <input type="submit" name="submit" onclick="drawChart()">  -->
   </form>
   <?php
    $structure = $_POST['select'];
    ?>
</div>


<!-- <?php
    include 'connection.php';
    $ycpArr = Array();
    $structure = isset($_POST['select']) ? $_POST['select'] : null;
    for($i=0;$i<=4;$i++){
        // $select = "SELECT SUM(obatinMarks)*100 / SUM(q.mark) AS plo 
        //            FROM evaluation AS e, question AS q,student AS s 
        //            WHERE e.studenID=s.studentID AND e.quesID = q.quesID AND q.coID LIKE '{$i}%' 
        //                  AND q.assessmentID LIKE '%CSE203+L_1_Summer_2021%'";
        $select = "SELECT SUM(obatinMarks)*100 / SUM(q.mark) AS plo, sc.schoolID 
                   FROM school AS sc, department AS d, program AS p, student AS s, evaluation AS e, question AS q 
                   WHERE sc.schoolID=d.schoolID AND d.deptShortName=p.deptShortName 
                   AND p.programID=s.programID AND e.studentID=s.studentID AND e.quesID = q.quesID AND q.coID LIKE '{$i}%' 
                   GROUP BY sc.schoolID";
        $result = mysqli_query($con,$select);
        while($travese = $result->fetch_assoc()){
          // array_push($ycpArr, $travese['total']);
          // array_push($ycpArr1, $travese['programID']);
          $ycpArr[$i][0]="co".$i;
          $ycpArr[$i][1]=$travese['plo'];
          $i++;
          
      }
    } 
    ?> -->
<script>
    // var obj = <?php echo json_encode($ycpArr); ?>;
    
</script>
<?php echo json_encode($ycpArr); ?>

<script type="text/javascript">
//var obj = <?php echo json_encode($ycpArr); ?>;
    var my_2d = [["PLO5","89"],["PLO1","69"],["PLO2","77"],["PLO3","65"],["PLO4","87"],["PLO5","57"],["PLO6","73"],["PLO7","81"],["PLO8","52"],["PLO9","71"],["PLO10","47"],["PLO11","78"],["PLO12","87"]]
    // var my_2d = [["PLO1","89"],["PLO2","69"],["PLO3","77"],["PLO4","57"]]
    // var obj = <?php echo json_encode($ycpArr); ?>;
      google.charts.load('current', {'packages':['corechart']});

      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        // Create the data table.
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Course');
        data.addColumn('number', 'PLO-Achievement');
        for(i = 0; i < obj.length; i++)
            data.addRow([obj[i][0],parseInt(obj[i][1])]);
        // Set chart options
        var options = {'title':'Course wise Performance',
                       'width':600,
                       'height':500,
			   is3D:true,};


        var chart = new google.visualization.<?php echo $structure ;?>(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
	
</script>

</div>
 <section>
    <div class="container">
        <div class = "row">
            <div class="col-lg-6 px-5 mr-3" align="center">
               <div id="chart_div"></div>
            </div>
        </div>
    </div>
</section>


    
</body>
</html>


<html>
<head>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-base.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-ui.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-exports.min.js"></script>
  <script src="https://cdn.anychart.com/releases/v8/js/anychart-radar.min.js"></script>
  <link href="https://cdn.anychart.com/releases/v8/css/anychart-ui.min.css" type="text/css" rel="stylesheet">
  <link href="https://cdn.anychart.com/releases/v8/fonts/css/anychart-font.min.css" type="text/css" rel="stylesheet">
  <style type="text/css">
    html,
      body,
      #container {
        width: 100%;
        height: 100%;
        margin: 0;
        padding: 0;
      }
  
</style>
</head>
<body>
    <div id="container"></div>

    <?php echo json_encode($ycpArr); ?>

    <script type="text/javascript">
    //var obj = <?php echo json_encode($ycpArr); ?>;
    // <?php

    //     include 'connection.php';
    //     $ycpArr = Array();
    //     $structure = isset($_POST['select']) ? $_POST['select'] : null;
    //     for($i=0;$i<=4;$i++){
    //         // $select = "SELECT SUM(obatinMarks)*100 / SUM(q.mark) AS plo 
    //         //            FROM evaluation AS e, question AS q,student AS s 
    //         //            WHERE e.studenID=s.studentID AND e.quesID = q.quesID AND q.coID LIKE '{$i}%' 
    //         //                  AND q.assessmentID LIKE '%CSE203+L_1_Summer_2021%'";
    //         $select = "SELECT SUM(obatinMarks)*100 / SUM(q.mark) AS plo, sc.schoolID 
    //                    FROM school AS sc, department AS d, program AS p, student AS s, evaluation AS e, question AS q 
    //                    WHERE e.studentID=s.studentID AND e.quesID = q.quesID AND q.coID LIKE '{$i}%' 
    //                    GROUP BY sc.schoolID";
    //         $result = mysqli_query($con,$select);
    //         while($travese = $result->fetch_assoc()){
    //           // array_push($ycpArr, $travese['total']);
    //           // array_push($ycpArr1, $travese['programID']);
    //           $ycpArr[$i][0]="co".$i;
    //           $ycpArr[$i][1]=$travese['plo'];
    //           $i++;
              
    //       }
    //     } 
         

    // ?>

    // var obj = <?php echo json_encode($ycpArr); ?>;
    // var obj4 = <?php echo json_encode($ycpArr1); ?>;

    anychart.onDocumentReady(function () {
        // create data set on our data
        var dataSet = anychart.data.set([
        ['PLO1', 0,0,69],
        ['PLO2', 81,67,59],
        ['PLO3', 66,0,0],
        ['PLO4', 0,0,69],
        ['PLO5', 0,76,78],
        ['PLO6', 0,0,0],
        ['PLO7', 0,0,0],
        ['PLO8', 0,69,0],
        ['PLO9', 71,54,0],
        ['PLO10', 79,0,77],
        ['PLO11', 0,0,0],
        ['PLO12', 0,56,79],
        // ['Spirit', 158, 64, 196]
        ]);

        // map data for the first series, take x from the zero column and value from the first column of data set
        var data1 = dataSet.mapAs({ x: 0, value: 1 });
        // map data for the second series, take x from the zero column and value from the second column of data set
        var data2 = dataSet.mapAs({ x: 0, value: 2 });
        // map data for the third series, take x from the zero column and value from the third column of data set
        var data3 = dataSet.mapAs({ x: 0, value: 3 });

        // create radar chart
        var chart = anychart.radar();

        // set chart title text settings
        chart.title(
        'Student Id Wise Performance into a Semester: '+'<?php echo "Summer"; ?>'
        );

        // set chart yScale settings
        chart.yScale().minimum(0).maximumGap(0).ticks().interval(50);

        // set xAxis labels settings
        chart.xAxis().labels().padding(5);

        // set chart legend settings
        chart.legend().align('center').enabled(true);

        
        // create first series with mapped data
        var series1 = chart.line(data1).name('SEMESTER: SUMMER');
        '<br>';
        var series1 = chart.line(data1).name('CSE303+L');
        series1.markers().enabled(true).type('circle').size(4);
        // create first series with mapped data
        var series2 = chart.line(data2).name('CSE309');
        series2.markers().enabled(true).type('circle').size(3);
        // create first series with mapped data
        var series3 = chart.line(data3).name('CSE416');
        series3.markers().enabled(true).type('circle').size(2);

        // chart tooltip format
        chart.tooltip().format('Value: {%Value}');

        // set container id for the chart
        chart.container('container');
        chart.draw();
    });

    </script>

   
</body>
</html>
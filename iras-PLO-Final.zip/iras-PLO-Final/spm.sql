-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2021 at 03:04 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spm`
--

-- --------------------------------------------------------

--
-- Table structure for table `activeness`
--

CREATE TABLE `activeness` (
  `name` varchar(15) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activeness`
--

INSERT INTO `activeness` (`name`, `status`) VALUES
('registration', 'true');

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE `assessment` (
  `assessmentID` varchar(29) NOT NULL,
  `totalMarks` float NOT NULL,
  `enrollmentID` varchar(25) NOT NULL,
  `nameOfAss` varchar(8) NOT NULL,
  `time` varchar(9) NOT NULL,
  `date` date NOT NULL,
  `duration` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`assessmentID`, `totalMarks`, `enrollmentID`, `nameOfAss`, `time`, `date`, `duration`) VALUES
('CSE203+L_1_Summer_2021_M1', 10, 'CSE203+L_1_Summer_2021', 'Mid', '00:38', '2021-05-24', '2: 00'),
('CSE203+L_1_Summer_2021_P1', 100, 'CSE203+L_1_Summer_2021', 'Project', '00:39', '2021-05-24', '2: 00'),
('CSE303+L_3_Summer_2021_M1', 15, 'CSE303+L_3_Summer_2021', 'Mid', '12:39', '2021-05-24', '2: 00'),
('CSE303+L_3_Summer_2021_Q1', 10, 'CSE303+L_3_Summer_2021', 'Quiz', '13:37', '2021-05-24', '2: 0'),
('CSE303+L_3_Summer_2021_Q2', 15, 'CSE303+L_3_Summer_2021', 'Quiz', '08:41', '2021-05-24', '1: 0');

-- --------------------------------------------------------

--
-- Table structure for table `co`
--

CREATE TABLE `co` (
  `coID` varchar(27) NOT NULL,
  `description` text NOT NULL,
  `courseLevel` int(11) NOT NULL,
  `enrollmentID` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `co`
--

INSERT INTO `co` (`coID`, `description`, `courseLevel`, `enrollmentID`) VALUES
('1_CSE203+L_1_Summer_2021', 'ABC', 2, 'CSE203+L_1_Summer_2021'),
('1_CSE303+L_3_Summer_2021', 'Understand the database applications starting from conceptual design using data models diagram (ERD), Process Model diagram (BPMN)', 3, 'CSE303+L_3_Summer_2021'),
('2_CSE203+L_1_Summer_2021', 'DEF', 2, 'CSE203+L_1_Summer_2021'),
('2_CSE303+L_3_Summer_2021', 'Basic understanding of data access structures and comparison between those structures, Determine the normalization form of Database.', 3, 'CSE303+L_3_Summer_2021'),
('3_CSE203+L_1_Summer_2021', 'GHI', 2, 'CSE203+L_1_Summer_2021'),
('3_CSE303+L_3_Summer_2021', 'Ability to analyze the ERD, Process diagram and normalization concept.', 3, 'CSE303+L_3_Summer_2021'),
('4_CSE203+L_1_Summer_2021', 'JKL', 2, 'CSE203+L_1_Summer_2021'),
('4_CSE303+L_3_Summer_2021', 'Solid foundation on the database design using query language SQL and design of user interfaces.', 3, 'CSE303+L_3_Summer_2021');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `courseID` varchar(9) NOT NULL,
  `courseName` varchar(50) NOT NULL,
  `noOfCredit` int(11) NOT NULL,
  `courseDescription` text NOT NULL,
  `programID` varchar(7) NOT NULL,
  `prequisiteCourseID1` varchar(9) NOT NULL,
  `prequisiteCourseID2` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`courseID`, `courseName`, `noOfCredit`, `courseDescription`, `programID`, `prequisiteCourseID1`, `prequisiteCourseID2`) VALUES
('CSC101+L', 'Introduction to Computer Programming', 4, 'This is an introductory course in Computer Science. The main objective of this course is to help the student develop a strong foundation of computer programming using C++. The programming concepts that will be covered in the class are variable, data types, input, output, arithmetic operation, control structures, logical operation, conditional statements, iterative statements, array, function, string. Each lecture would involve solving a number of programming problems using the computer', 'CSE', 'none', 'none'),
('CSE104+L', 'Electrical Circuit Analysis', 4, 'Passive electrical components. Electric circuit concepts and relationship to field theory. Kirchhoff\'s laws. Node and mesh analysis of resistive networks. Network theorems. Controlled sources. Transient conditions. Sources of periodic signals. Average and r.m.s. values. Circuit models of diodes and transistors. Combinational logic principles and circuits. RLC circuits; sinusoidal circuit response; mutual inductance and transformers; operational amplifiers; computer aided circuit design; state space circuit representations and time responses; homogenous and particular solutions for first and second order linear differential equations; computer aided analysis of signals and systems, including state space representations; continuous time signals, sinusoids and signal norms; convolution, impulse and step responses; phasors; AC circuits (transient and steady state responses); complex power; frequency responses of circuits and systems; three-phase circuits. ', 'CSE', 'none', 'none'),
('CSE201', 'Discrete Mathematics', 4, 'This course covers elementary discrete mathematics required for computer science and engineering students. Emphasis is placed on mathematical definitions and proofs as well as methods of application. Topics include a review of set theory, formal logic notation and operations, methods of proof, induction, permutations and combinations, basic and advanced counting techniques, recurrence relations, generating functions, graph theory and finite state machines', 'CSE', 'CSC101+L', 'none'),
('CSE203+L', 'Data Structure', 4, 'Data representation and storage in elementary data structures like arrays and linked lists (both singly linked lists and doubly linked lists). Abstract Data Types (ADT): Stack, Queue, Priority Queue. Comparative analysis of different implementations of ADTs ', 'CSE', 'CSE201', 'CSC101+L'),
('CSE303+L', 'Database Management', 4, 'An introduction to database design and the use of database management systems. The course includes detailed coverage of the development process, database architectural principles, relational algebra and SQL using Oracle or SQL Server. Other key database topics covered are data modelling (E-R model, relational data model, integrity constraints, data model operations, normalization, object oriented data modelling), database security, administration and distributed systems.', 'CSE', 'CSE203+L', 'CSE201'),
('CSE307', 'System Analysis and Design', 4, 'This course examines the tools and techniques used for the design and analysis of information systems. Topics covered include: Systems and models; Project management; Tools for determining system requirements; data flow diagrams; decision table and decision trees; Systems analysis: systems development life cycle models. Object oriented analysis: use-case modeling, Unified Modeling Language. Feasibility analysis, Structured analysis; systems prototyping; system design and implementation: application architecture, user interface design. Front-end and backend design; database design; software management and hardware selection. Case studies of Information Systems.', 'CSE', 'CSE303+L', 'CSE203+L');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `deptShortName` varchar(7) NOT NULL,
  `deptName` varchar(35) NOT NULL,
  `schoolID` varchar(6) NOT NULL,
  `universityID` int(11) NOT NULL,
  `facultyIDInCharge` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`deptShortName`, `deptName`, `schoolID`, `universityID`, `facultyIDInCharge`) VALUES
('CSE', 'Computer Science & Engineering', 'SETS', 1, '1234'),
('EEE', 'Electrical & Electronics Engineerin', 'SETS', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `evaluation`
--

CREATE TABLE `evaluation` (
  `evaluationID` varchar(36) NOT NULL,
  `studentAns` text NOT NULL,
  `enrollmentID` varchar(25) NOT NULL,
  `quesID` varchar(33) NOT NULL,
  `studentID` varchar(7) NOT NULL,
  `obatinMarks` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `evaluation`
--

INSERT INTO `evaluation` (`evaluationID`, `studentAns`, `enrollmentID`, `quesID`, `studentID`, `obatinMarks`) VALUES
('1730016_CSE203+L_1_Summer_2021_M1_1', 'done', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1_1', '1730016', 0),
('1730016_CSE203+L_1_Summer_2021_M1_2', '11', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1_2', '1730016', 5),
('1730016_CSE203+L_1_Summer_2021_P1_1', 'done', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_P1_1', '1730016', 5),
('1730016_CSE303+L_3_Summer_2021_Q1_1', '9', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q1_1', '1730016', 5),
('1730016_CSE303+L_3_Summer_2021_Q1_2', '15', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q1_2', '1730016', 5),
('1731407_CSE203+L_1_Summer_2021_M1_1', 'done', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1_1', '1731407', 0),
('1731407_CSE203+L_1_Summer_2021_M1_2', '11', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1_2', '1731407', 5),
('1731407_CSE303+L_3_Summer_2021_Q1_1', '9', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q1_1', '1731407', 5),
('1731407_CSE303+L_3_Summer_2021_Q1_2', '15', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q1_2', '1731407', 4),
('1731462_CSE203+L_1_Summer_2021_M1_1', 'done', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1_1', '1731462', 4),
('1731462_CSE203+L_1_Summer_2021_M1_2', '11', 'CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1_2', '1731462', 4),
('1731462_CSE303+L_3_Summer_2021_M1_1', '5', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_M1_1', '1731462', 5),
('1731462_CSE303+L_3_Summer_2021_M1_2', '81', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_M1_2', '1731462', 0),
('1731462_CSE303+L_3_Summer_2021_M1_3', '2', 'CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_M1_3', '1731462', 5);

-- --------------------------------------------------------

--
-- Table structure for table `evaluation_faculty`
--

CREATE TABLE `evaluation_faculty` (
  `evaluationID` varchar(33) NOT NULL,
  `facultyID` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `facultyID` varchar(4) NOT NULL,
  `facultyName` varchar(40) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contactNo` varchar(15) NOT NULL,
  `deptShortName` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`facultyID`, `facultyName`, `dob`, `gender`, `email`, `contactNo`, `deptShortName`) VALUES
('1234', 'Dr. Mahadi Hassan', '1779-03-01', 'male', 'mahady@iub.edu.bd', '01234556789', 'CSE'),
('1235', 'AKM Mahbubur Rahman', '1972-03-01', 'male', 'akmmrrahman@iub.edu.bd', '01234567895', 'CSE'),
('1236', 'Abu Sayed', '1772-03-18', 'male', 'sayed@iub.edu.bd', '01234567896', 'CSE'),
('1237', 'Sadita Ahmed', '1772-03-12', 'female', 'sadita.ahsets@iub.edu.bd', '01234567893', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `plo`
--

CREATE TABLE `plo` (
  `ploID` varchar(5) NOT NULL,
  `name` varchar(35) NOT NULL,
  `details` text NOT NULL,
  `lavel` int(11) NOT NULL,
  `programID` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plo`
--

INSERT INTO `plo` (`ploID`, `name`, `details`, `lavel`, `programID`) VALUES
('1', 'Engineering knowledge', 'Apply knowledge of mathematics, natural science, engineering fundamentals and an engineering specialization as specified in K1 to K4 respectively to the solution of complex engineering problems', 1, 'CSE'),
('10', 'Communication', 'Communicate effectively on complex engineering activities with the engineering community and with society at large, such as being able to comprehend and write effective reports and design documentation, make effective presentations, and give and receive clear instructions', 3, 'CSE'),
('11', 'Project management and finance', 'Demonstrate knowledge and understanding of engineering management principles and economic decision-making and apply these to one’s own work, as a member and leader in a team, to manage projects and in multidisciplinary environments.', 6, 'CSE'),
('12', 'Life-long learning', 'Recognize the need for, and have the preparation and ability to engage in independent and life-long learning in the broadest context of technological change', 6, 'CSE'),
('2', 'Problem analysis', 'Identify, formulate, research literature and analyse complex engineering problems reaching substantiated conclusions using first principles of mathematics, natural sciences and engineering sciences. ', 4, 'CSE'),
('3', 'Design/development of solution', 'Design solutions for complex engineering problems and design systems, components or processes that meet specified needs with appropriate consideration for public health and safety, cultural, societal, and environmental considerations', 3, 'CSE'),
('4', 'Investigation', 'Conduct investigations of complex problems using research-based knowledge (K8) and research methods including design of experiments, analysis and interpretation of data, and synthesis of information to provide valid conclusions.', 4, 'CSE'),
('5', 'Modern tool usage', 'Create, select and apply appropriate techniques, resources, and modern engineering and IT tools, including prediction and modelling, to complex engineering problems, with an understanding of the limitations.', 3, 'CSE'),
('6', 'The engineer and society', 'Apply reasoning informed by contextual knowledge to assess societal, health, safety, legal and cultural issues and the consequent responsibilities relevant to professional engineering practice and solutions to complex engineering problems', 3, 'CSE'),
('7', 'Environment and sustainability', 'Understand and evaluate the sustainability and impact of professional engineering work in the solution of complex engineering problems in societal and environmental contexts', 5, 'CSE'),
('8', 'Ethics', 'Apply ethical principles and commit to professional ethics and responsibilities and norms of engineering practice', 3, 'CSE'),
('9', 'Individual work and teamwork', 'Function effectively as an individual, and as a member or leader in diverse teams and in multi-disciplinary settings. ', 2, 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `plocomapping`
--

CREATE TABLE `plocomapping` (
  `ploID` varchar(5) NOT NULL,
  `coID` varchar(27) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plocomapping`
--

INSERT INTO `plocomapping` (`ploID`, `coID`) VALUES
('2', '1_CSE303+L_3_Summer_2021'),
('3', '2_CSE303+L_3_Summer_2021'),
('9', '3_CSE303+L_3_Summer_2021'),
('10', '4_CSE303+L_3_Summer_2021'),
('2', '1_CSE203+L_1_Summer_2021'),
('4', '2_CSE203+L_1_Summer_2021'),
('9', '3_CSE203+L_1_Summer_2021'),
('10', '4_CSE203+L_1_Summer_2021'),
('1', '2_CSE303+L_3_Summer_2021'),
('2', '2_CSE203+L_1_Summer_2021'),
('5', '1_CSE203+L_1_Summer_2021'),
('6', '1_CSE303+L_3_Summer_2021'),
('7', '4_CSE303+L_3_Summer_2021'),
('8', '2_CSE203+L_1_Summer_2021'),
('11', '4_CSE203+L_1_Summer_2021'),
('12', '4_CSE303+L_3_Summer_2021');

-- --------------------------------------------------------

--
-- Table structure for table `ploinitialmapping`
--

CREATE TABLE `ploinitialmapping` (
  `ploID` varchar(5) NOT NULL,
  `courseID` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ploinitialmapping`
--

INSERT INTO `ploinitialmapping` (`ploID`, `courseID`) VALUES
('1', 'CSC101+L'),
('2', 'CSC101+L'),
('3', 'CSC101+L'),
('4', 'CSC101+L'),
('1', 'CSE104+L'),
('2', 'CSE104+L'),
('3', 'CSE104+L'),
('5', 'CSE104+L'),
('1', 'CSE201'),
('2', 'CSE201'),
('4', 'CSE201'),
('8', 'CSE201'),
('2', 'CSE203+L'),
('4', 'CSE203+L'),
('9', 'CSE203+L'),
('10', 'CSE203+L'),
('2', 'CSE303+L'),
('3', 'CSE303+L'),
('9', 'CSE303+L'),
('10', 'CSE303+L');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `programID` varchar(7) NOT NULL,
  `programName` varchar(30) NOT NULL,
  `deptShortName` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`programID`, `programName`, `deptShortName`) VALUES
('CE', 'Computer Engineering', 'CSE'),
('CS', 'Computer Science', 'CSE'),
('CSE', 'Computer Science & Engineering', 'CSE'),
('EEE', 'Electrical & Electronic Engine', 'EEE');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `quesID` varchar(31) NOT NULL,
  `mark` float NOT NULL,
  `details` text NOT NULL,
  `sampleAns` int(11) NOT NULL,
  `facultyID` varchar(4) NOT NULL,
  `coID` varchar(27) NOT NULL,
  `assessmentID` varchar(29) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`quesID`, `mark`, `details`, `sampleAns`, `facultyID`, `coID`, `assessmentID`) VALUES
('CSE203+L_1_Summer_2021_M1_1', 5, 'write this code', 0, '1236', '2_CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1'),
('CSE203+L_1_Summer_2021_M1_2', 10, '5+6', 11, '1236', '3_CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_M1'),
('CSE203+L_1_Summer_2021_P1_1', 71, 'making calculator.', 0, '1236', '2_CSE203+L_1_Summer_2021', 'CSE203+L_1_Summer_2021_P1'),
('CSE303+L_3_Summer_2021_M1_1', 5, '15/3', 5, '1234', '1_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_M1'),
('CSE303+L_3_Summer_2021_M1_2', 15, '12+59', 71, '1234', '2_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_M1'),
('CSE303+L_3_Summer_2021_M1_3', 12, '14/7.0', 2, '1234', '3_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_M1'),
('CSE303+L_3_Summer_2021_Q1_1', 30, '3+6', 9, '1234', '1_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q1'),
('CSE303+L_3_Summer_2021_Q1_2', 55, '6+9', 15, '1234', '2_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q1'),
('CSE303+L_3_Summer_2021_Q2_1', 10, '3+2', 5, '1234', '1_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q2'),
('CSE303+L_3_Summer_2021_Q2_2', 45, '8+9', 17, '1234', '2_CSE303+L_3_Summer_2021', 'CSE303+L_3_Summer_2021_Q2');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `studentID` varchar(7) NOT NULL,
  `enrollmentID` varchar(25) NOT NULL,
  `totalMakrs` float NOT NULL,
  `CO1` float NOT NULL,
  `CO2` float NOT NULL,
  `CO3` float NOT NULL,
  `CO4` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`studentID`, `enrollmentID`, `totalMakrs`, `CO1`, `CO2`, `CO3`, `CO4`) VALUES
('1730016', 'CSE203+L_1_Summer_2021', 15, 50, 10.4651, 46.6667, 95.5),
('1730016', 'CSE303+L_3_Summer_2021', 17.5, 50, 65, 75, 95.5),
('1731462', 'CSC101+L_1_Summer_2021', 20, 90, 80, 55, 45.5),
('1731462', 'CSE203+L_1_Summer_2021', 20, 90, 80, 55, 45.5),
('1731462', 'CSE303+L_3_Summer_2021', 20, 90, 80, 55, 45.5),
('1731407', 'CSE203+L_1_Summer_2021', 15, 55.5, 20, 30, 45.5),
('1731407', 'CSE303+L_3_Summer_2021', 16.5, 55.5, 20, 30, 45.5);

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `schoolID` varchar(6) NOT NULL,
  `schoolName` varchar(45) NOT NULL,
  `universityID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`schoolID`, `schoolName`, `universityID`) VALUES
('BBA', 'School of business', 1),
('SETS', 'School of Engineering, Technology & Sciences', 1);

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `sectionID` int(11) NOT NULL,
  `courseID` varchar(9) NOT NULL,
  `year` year(4) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `totalEnrollment` int(11) NOT NULL,
  `roomNo` varchar(7) NOT NULL,
  `classTime` varchar(17) NOT NULL,
  `day` int(2) NOT NULL,
  `totalNumberOfStudent` int(11) NOT NULL,
  `facultyID` varchar(4) NOT NULL,
  `facultyIDModaretor` varchar(4) NOT NULL,
  `enrollmentID` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`sectionID`, `courseID`, `year`, `semester`, `totalEnrollment`, `roomNo`, `classTime`, `day`, `totalNumberOfStudent`, `facultyID`, `facultyIDModaretor`, `enrollmentID`) VALUES
(1, 'CSC101+L', 2021, 'Summer', 35, '3012', '11:00-12:30 ', 0, 1, '1235', '1236', 'CSC101+L_1_Summer_2021'),
(1, 'CSE203+L', 2021, 'Summer', 25, '6002', '14:00-15:30 ', 0, 3, '1236', '1236', 'CSE203+L_1_Summer_2021'),
(1, 'CSE303+L', 2021, 'Summer', 25, '7004', '14:00-15:30 ', 0, 0, '1236', '1234', 'CSE303+L_1_Summer_2021'),
(2, 'CSE303+L', 2021, 'Summer', 25, '6004', '15:30-17:00 ', 0, 0, '1237', '1234', 'CSE303+L_2_Summer_2021'),
(3, 'CSE303+L', 2021, 'Summer', 25, '6005', '17:00-18:30  ', 0, 3, '1234', '1234', 'CSE303+L_3_Summer_2021');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(15) NOT NULL,
  `studentID` varchar(7) NOT NULL,
  `semester` varchar(6) NOT NULL,
  `year` varchar(4) NOT NULL,
  `email` varchar(30) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `programID` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`fname`, `lname`, `studentID`, `semester`, `year`, `email`, `contact`, `dob`, `gender`, `programID`) VALUES
('Partho Protim', 'Saha', '1730016', 'Summer', '2017', '1730016@iub.edu.bd', '01881068129', '1999-08-30', 'male', 'CSE'),
('Riyad', 'Hossain', '1731407', 'Summer', '2017', '1731407@iub.edu.bd', '01234567896', '1998-04-10', 'male', 'CSE'),
('Ahnaf', 'Tazwer Araf', '1731462', 'Summer', '2017', '1731462@iub.edu.bd', '01234567896', '1995-06-05', 'male', 'CSE'),
('Mohitul', 'Shafir', '1731490', 'Summer', '2017', '1731490@iub.edu.bd', '012345667891', '1997-11-27', 'male', 'CSE'),
('Afra', 'Hossain', '1811011', 'Autumn', '2018', '1811011@iub.edu.bd', '012345678898', '1997-03-12', 'female', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `university`
--

CREATE TABLE `university` (
  `universityID` int(11) NOT NULL,
  `universityName` varchar(100) NOT NULL,
  `location` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `university`
--

INSERT INTO `university` (`universityID`, `universityName`, `location`) VALUES
(1, 'Independent University, Bangladesh', 'Bashundhara');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assessment`
--
ALTER TABLE `assessment`
  ADD PRIMARY KEY (`assessmentID`),
  ADD KEY `enrollmentID` (`enrollmentID`);

--
-- Indexes for table `co`
--
ALTER TABLE `co`
  ADD PRIMARY KEY (`coID`),
  ADD KEY `enrollmentID` (`enrollmentID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`courseID`),
  ADD KEY `programID` (`programID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`deptShortName`),
  ADD KEY `universityID` (`universityID`),
  ADD KEY `schoolID` (`schoolID`);

--
-- Indexes for table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`evaluationID`),
  ADD KEY `studentID` (`studentID`),
  ADD KEY `enrollmentID` (`enrollmentID`),
  ADD KEY `quesID` (`quesID`);

--
-- Indexes for table `evaluation_faculty`
--
ALTER TABLE `evaluation_faculty`
  ADD KEY `evaluationID` (`evaluationID`),
  ADD KEY `facultyID` (`facultyID`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`facultyID`),
  ADD KEY `deptShortName` (`deptShortName`);

--
-- Indexes for table `plo`
--
ALTER TABLE `plo`
  ADD PRIMARY KEY (`ploID`),
  ADD KEY `programID` (`programID`);

--
-- Indexes for table `plocomapping`
--
ALTER TABLE `plocomapping`
  ADD KEY `coID` (`coID`),
  ADD KEY `ploID` (`ploID`);

--
-- Indexes for table `ploinitialmapping`
--
ALTER TABLE `ploinitialmapping`
  ADD KEY `courseID` (`courseID`),
  ADD KEY `ploID` (`ploID`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`programID`),
  ADD KEY `deptShortName` (`deptShortName`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`quesID`),
  ADD KEY `assessmentID` (`assessmentID`),
  ADD KEY `coID` (`coID`),
  ADD KEY `facultyID` (`facultyID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD KEY `studentID` (`studentID`),
  ADD KEY `enrollmentID` (`enrollmentID`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`schoolID`),
  ADD KEY `universityID` (`universityID`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`enrollmentID`),
  ADD KEY `courseID` (`courseID`),
  ADD KEY `facultyID` (`facultyID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentID`),
  ADD KEY `programID` (`programID`);

--
-- Indexes for table `university`
--
ALTER TABLE `university`
  ADD PRIMARY KEY (`universityID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `university`
--
ALTER TABLE `university`
  MODIFY `universityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assessment`
--
ALTER TABLE `assessment`
  ADD CONSTRAINT `assessment_ibfk_1` FOREIGN KEY (`enrollmentID`) REFERENCES `section` (`enrollmentID`);

--
-- Constraints for table `co`
--
ALTER TABLE `co`
  ADD CONSTRAINT `co_ibfk_1` FOREIGN KEY (`enrollmentID`) REFERENCES `section` (`enrollmentID`);

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`programID`) REFERENCES `program` (`programID`);

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`universityID`) REFERENCES `university` (`universityID`),
  ADD CONSTRAINT `department_ibfk_2` FOREIGN KEY (`schoolID`) REFERENCES `school` (`schoolID`);

--
-- Constraints for table `evaluation`
--
ALTER TABLE `evaluation`
  ADD CONSTRAINT `evaluation_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `student` (`studentID`),
  ADD CONSTRAINT `evaluation_ibfk_2` FOREIGN KEY (`enrollmentID`) REFERENCES `section` (`enrollmentID`),
  ADD CONSTRAINT `evaluation_ibfk_3` FOREIGN KEY (`quesID`) REFERENCES `question` (`quesID`);

--
-- Constraints for table `evaluation_faculty`
--
ALTER TABLE `evaluation_faculty`
  ADD CONSTRAINT `evaluation_faculty_ibfk_1` FOREIGN KEY (`evaluationID`) REFERENCES `evaluation` (`evaluationID`),
  ADD CONSTRAINT `evaluation_faculty_ibfk_2` FOREIGN KEY (`facultyID`) REFERENCES `faculty` (`facultyID`);

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`deptShortName`) REFERENCES `department` (`deptShortName`);

--
-- Constraints for table `plo`
--
ALTER TABLE `plo`
  ADD CONSTRAINT `plo_ibfk_1` FOREIGN KEY (`programID`) REFERENCES `program` (`programID`);

--
-- Constraints for table `plocomapping`
--
ALTER TABLE `plocomapping`
  ADD CONSTRAINT `plocomapping_ibfk_1` FOREIGN KEY (`coID`) REFERENCES `co` (`coID`),
  ADD CONSTRAINT `plocomapping_ibfk_2` FOREIGN KEY (`ploID`) REFERENCES `plo` (`ploID`);

--
-- Constraints for table `ploinitialmapping`
--
ALTER TABLE `ploinitialmapping`
  ADD CONSTRAINT `ploinitialmapping_ibfk_1` FOREIGN KEY (`courseID`) REFERENCES `course` (`courseID`),
  ADD CONSTRAINT `ploinitialmapping_ibfk_2` FOREIGN KEY (`ploID`) REFERENCES `plo` (`ploID`);

--
-- Constraints for table `program`
--
ALTER TABLE `program`
  ADD CONSTRAINT `program_ibfk_1` FOREIGN KEY (`deptShortName`) REFERENCES `department` (`deptShortName`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`assessmentID`) REFERENCES `assessment` (`assessmentID`),
  ADD CONSTRAINT `question_ibfk_2` FOREIGN KEY (`coID`) REFERENCES `co` (`coID`),
  ADD CONSTRAINT `question_ibfk_3` FOREIGN KEY (`facultyID`) REFERENCES `faculty` (`facultyID`);

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_1` FOREIGN KEY (`studentID`) REFERENCES `student` (`studentID`),
  ADD CONSTRAINT `registration_ibfk_2` FOREIGN KEY (`enrollmentID`) REFERENCES `section` (`enrollmentID`);

--
-- Constraints for table `school`
--
ALTER TABLE `school`
  ADD CONSTRAINT `school_ibfk_1` FOREIGN KEY (`universityID`) REFERENCES `university` (`universityID`);

--
-- Constraints for table `section`
--
ALTER TABLE `section`
  ADD CONSTRAINT `section_ibfk_1` FOREIGN KEY (`courseID`) REFERENCES `course` (`courseID`),
  ADD CONSTRAINT `section_ibfk_2` FOREIGN KEY (`facultyID`) REFERENCES `faculty` (`facultyID`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`programID`) REFERENCES `program` (`programID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
